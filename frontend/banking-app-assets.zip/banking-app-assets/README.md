This assets come from this nextjs tutorial: 

(https://www.youtube.com/watch?v=PuOVqP_cjkE&t=2180s)[Banking app]

